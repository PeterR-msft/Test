# Description

The xADOrganizational Unit DSC resource will manage Organizational Units (OUs) within Active Directory. An OU is a subdivision within an Active Directory into which you can place users, groups, computers, and other organizational units.
